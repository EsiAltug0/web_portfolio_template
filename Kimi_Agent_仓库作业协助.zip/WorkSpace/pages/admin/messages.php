<?php
// ============================================
// ADMIN PANELI - Mesaj Yönetimi
// Sadece admin kullanıcılar erişebilir
// Mesajları listeleme, silme, okundu işaretleme
// ============================================
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/db.php';

// Admin kontrolü
requireAdmin();

$pageTitle = 'Admin Paneli';
$basePath = '../../';
$navBasePath = '../../';

// Silme işlemi
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    try {
        $db = getDB();
        $stmt = $db->prepare("DELETE FROM messages WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        setFlashMessage('success', 'Mesaj başarıyla silindi.');
    } catch (PDOException $e) {
        setFlashMessage('error', 'Silme işlemi başarısız oldu.');
    }
    header("Location: messages.php");
    exit;
}

// Okundu işaretleme
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    try {
        $db = getDB();
        $stmt = $db->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
        $stmt->execute([$_GET['mark_read']]);
        setFlashMessage('success', 'Mesaj okundu olarak işaretlendi.');
    } catch (PDOException $e) {
        setFlashMessage('error', 'İşlem başarısız oldu.');
    }
    header("Location: messages.php");
    exit;
}

// Tümünü okundu işaretleme
if (isset($_GET['mark_all_read'])) {
    try {
        $db = getDB();
        $db->query("UPDATE messages SET is_read = 1");
        setFlashMessage('success', 'Tüm mesajlar okundu olarak işaretlendi.');
    } catch (PDOException $e) {
        setFlashMessage('error', 'İşlem başarısız oldu.');
    }
    header("Location: messages.php");
    exit;
}

// Mesajları getir
try {
    $db = getDB();
    
    // Filtreleme
    $filter = $_GET['filter'] ?? 'all';
    $whereClause = '';
    $params = [];
    
    if ($filter === 'unread') {
        $whereClause = 'WHERE is_read = 0';
    } elseif ($filter === 'read') {
        $whereClause = 'WHERE is_read = 1';
    }
    
    // Mesajları getir
    $stmt = $db->prepare("SELECT * FROM messages $whereClause ORDER BY created_at DESC");
    $stmt->execute($params);
    $messages = $stmt->fetchAll();
    
    // İstatistikler
    $totalCount = $db->query("SELECT COUNT(*) FROM messages")->fetchColumn();
    $unreadCount = $db->query("SELECT COUNT(*) FROM messages WHERE is_read = 0")->fetchColumn();
    
} catch (PDOException $e) {
    $messages = [];
    $totalCount = 0;
    $unreadCount = 0;
}

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
.admin-container { max-width: 1200px; }
.admin-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}
.stat-card {
    background: rgba(0, 212, 255, 0.05);
    border: 1px solid var(--border);
    border-radius: 15px;
    padding: 1.5rem;
    text-align: center;
}
.stat-number {
    font-family: 'Orbitron', sans-serif;
    font-size: 2.5rem;
    font-weight: 900;
    color: var(--primary);
}
.stat-label {
    color: var(--text-light);
    font-size: 0.9rem;
    margin-top: 0.5rem;
}
.filter-nav {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
}
.filter-btn {
    background: rgba(0, 212, 255, 0.05);
    border: 1px solid var(--border);
    color: var(--text);
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    cursor: pointer;
    font-family: 'Space Grotesk', sans-serif;
    font-weight: 600;
    transition: all 0.3s ease;
    text-decoration: none;
}
.filter-btn:hover, .filter-btn.active {
    background: var(--primary);
    color: var(--bg);
    border-color: var(--primary);
}
.message-card {
    background: rgba(0, 212, 255, 0.03);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 1rem;
    transition: all 0.3s ease;
}
.message-card:hover {
    border-color: var(--primary);
}
.message-card.unread {
    border-left: 4px solid var(--primary);
    background: rgba(0, 212, 255, 0.08);
}
.message-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
    flex-wrap: wrap;
    gap: 1rem;
}
.message-sender {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}
.sender-name {
    font-family: 'Orbitron', sans-serif;
    font-weight: 700;
    color: var(--primary);
}
.sender-email {
    font-size: 0.85rem;
    color: var(--text-light);
}
.message-meta {
    display: flex;
    gap: 1rem;
    align-items: center;
    flex-wrap: wrap;
}
.message-type {
    background: rgba(255, 0, 85, 0.15);
    color: var(--red);
    padding: 0.25rem 0.75rem;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
}
.message-date {
    font-size: 0.8rem;
    color: var(--text-light);
    font-family: 'Space Mono', monospace;
}
.message-subject {
    font-weight: 700;
    color: var(--text);
    margin-bottom: 0.5rem;
}
.message-body {
    color: var(--text-light);
    line-height: 1.6;
    margin-bottom: 1rem;
}
.message-actions {
    display: flex;
    gap: 0.75rem;
    flex-wrap: wrap;
}
.action-btn {
    padding: 0.5rem 1rem;
    border-radius: 6px;
    font-size: 0.85rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    border: none;
    font-family: 'Space Grotesk', sans-serif;
}
.btn-read {
    background: rgba(0, 212, 255, 0.1);
    color: var(--primary);
    border: 1px solid var(--primary);
}
.btn-read:hover {
    background: var(--primary);
    color: var(--bg);
}
.btn-delete {
    background: rgba(255, 0, 85, 0.1);
    color: var(--red);
    border: 1px solid var(--red);
}
.btn-delete:hover {
    background: var(--red);
    color: white;
}
.badge {
    background: var(--primary);
    color: var(--bg);
    font-size: 0.75rem;
    padding: 0.15rem 0.5rem;
    border-radius: 10px;
    font-weight: 700;
}
.no-messages {
    text-align: center;
    padding: 3rem;
    color: var(--text-light);
    border: 2px dashed var(--border);
    border-radius: 15px;
}
</style>

<?php include __DIR__ . '/../../includes/navbar.php'; ?>

<main class="pages-container">
    <section class="page active">
        <div class="section-container admin-container">
            <div class="section-header">
                <span class="section-number">ADM</span>
                <div class="section-divider"></div>
            </div>
            <h2 class="section-title">MESAJ YÖNETİMİ</h2>

            <?php showFlashMessage(); ?>

            <!-- İstatistikler -->
            <div class="admin-stats">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $totalCount; ?></div>
                    <div class="stat-label">Toplam Mesaj</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" style="color: var(--primary);"><?php echo $unreadCount; ?></div>
                    <div class="stat-label">Okunmamış</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" style="color: var(--red);"><?php echo $totalCount - $unreadCount; ?></div>
                    <div class="stat-label">Okunmuş</div>
                </div>
            </div>

            <!-- Filtreler -->
            <div class="filter-nav">
                <a href="?filter=all" class="filter-btn <?php echo $filter === 'all' ? 'active' : ''; ?>">
                    Tümü <?php if ($totalCount > 0): ?><span class="badge"><?php echo $totalCount; ?></span><?php endif; ?>
                </a>
                <a href="?filter=unread" class="filter-btn <?php echo $filter === 'unread' ? 'active' : ''; ?>">
                    Okunmamış <?php if ($unreadCount > 0): ?><span class="badge"><?php echo $unreadCount; ?></span><?php endif; ?>
                </a>
                <a href="?filter=read" class="filter-btn <?php echo $filter === 'read' ? 'active' : ''; ?>">Okunmuş</a>
                <a href="?mark_all_read=1" class="filter-btn" style="margin-left: auto; background: rgba(0, 212, 255, 0.1);" 
                   onclick="return confirm('Tüm mesajları okundu olarak işaretlemek istiyor musunuz?')">
                    Tümünü Okundu İşaretle
                </a>
            </div>

            <!-- Mesaj Listesi -->
            <?php if (empty($messages)): ?>
                <div class="no-messages">
                    <h3>Henüz mesaj bulunmuyor</h3>
                    <p>Gelen mesajlar burada listelenecektir.</p>
                </div>
            <?php else: ?>
                <?php foreach ($messages as $msg): ?>
                <div class="message-card <?php echo $msg['is_read'] ? '' : 'unread'; ?>">
                    <div class="message-header">
                        <div class="message-sender">
                            <span class="sender-name"><?php echo e($msg['name']); ?></span>
                            <span class="sender-email"><?php echo e($msg['email']); ?> <?php if ($msg['phone']): ?>| <?php echo e($msg['phone']); ?><?php endif; ?></span>
                        </div>
                        <div class="message-meta">
                            <span class="message-type"><?php echo e($msg['msg_type']); ?></span>
                            <span class="message-date"><?php echo e($msg['created_at']); ?></span>
                            <?php if (!$msg['is_read']): ?>
                                <span style="color: var(--primary); font-size: 0.75rem; font-weight: 700;">● YENİ</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="message-subject"><?php echo e($msg['subject']); ?></div>
                    <div class="message-body"><?php echo nl2br(e($msg['message'])); ?></div>
                    <div class="message-actions">
                        <?php if (!$msg['is_read']): ?>
                        <a href="?mark_read=<?php echo $msg['id']; ?>" class="action-btn btn-read">✓ Okundu İşaretle</a>
                        <?php endif; ?>
                        <a href="?delete=<?php echo $msg['id']; ?>" class="action-btn btn-delete" 
                           onclick="return confirm('Bu mesajı silmek istediğinize emin misiniz?')">🗑 Sil</a>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php 
$footerBasePath = '../../';
include __DIR__ . '/../../includes/footer.php'; 
?>
