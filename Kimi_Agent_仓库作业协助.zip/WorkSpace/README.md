# Esma Portfolio 2026 - Final Proje

Kişisel portfolyo web sitesi. HTML, CSS, JavaScript, PHP ve MySQL teknolojileri kullanılarak geliştirilmiştir.

## Proje Hakkında

Bu proje, Kırşehir Ahi Evran Üniversitesi Bilgisayar Programcılığı bölümü Web Programlama dersi final projesi olarak geliştirilmiştir.

## Kullanılan Teknolojiler

### Frontend
- **HTML5** - Sayfa yapısı
- **CSS3** - Stil ve animasyonlar
- **JavaScript (Vanilla)** - Etkileşim ve dinamik içerik
- **Google Fonts** - Orbitron, Space Grotesk, Space Mono

### Backend
- **PHP 8.x** - Sunucu taraflı işlemler
- **MySQL** - Veritabanı yönetimi
- **PDO** - Güvenli veritabanı bağlantısı

## Özellikler

### 1. Kullanıcı Deneyimi Özellikleri
- **Arama Kutusu** - Projeler arasında anahtar kelime ile arama
- **Kategori Filtreleme** - Projeleri kategoriye göre filtreleme (Web Geliştirme, Mobil Uygulama, Veri Bilimi, vb.)
- **İsme Göre Sıralama** - A-Z ve Z-A sıralama seçenekleri
- **Galeri / Proje Filtreleme** - Dinamik proje kartları ile filtreleme

### 2. API ve Dinamik Veri Kullanımı
- **JSON Dosyasından Veri Okuma** - `data/projects.json` dosyasından proje verileri çekilerek kart yapısında listelenir
- **Dinamik Filtreleme** - Arama, kategori ve sıralama işlemleri sunucu taraflı PHP ile yapılır

### 3. Veritabanı İşlemleri (PHP + MySQL)
- **Kullanıcı Kayıt Olma** - `pages/register.php`
- **Kullanıcı Giriş Yapma** - `pages/login.php` (Session yönetimi)
- **Veritabanına Veri Ekleme** - İletişim formu verileri `messages` tablosuna kaydedilir
- **Veritabanından Veri Listeleme** - Admin panelinde mesajlar listelenir
- **Veri Güncelleme** - Mesajları okundu olarak işaretleme
- **Veri Silme** - Admin panelinden mesaj silme

### 4. Ek Özellikler
- **Admin Paneli** - Sadece admin kullanıcıların erişebildiği mesaj yönetim ekranı (`pages/admin/messages.php`)
- **Tema Değiştirme** - Karanlık / Aydınlık mod (localStorage ile kalıcı)
- **Mobil Uyumlu Tasarım** - Responsive layout
- **Form Doğrulama** - Hem istemci taraflı (JS) hem sunucu taraflı (PHP) validasyon
- **Flash Mesajlar** - İşlem sonuçlarını kullanıcıya bildirim

## Kurulum

### Gereksinimler
- XAMPP, WAMP veya benzeri bir yerel sunucu ortamı
- PHP 8.0 veya üzeri
- MySQL 5.7 veya üzeri

### Adımlar

1. **Projeyi İndirin**
   ```bash
   git clone -b feature/final-project https://github.com/EsiAltug0/web_portfolio_template.git
   cd web_portfolio_template
   ```

2. **Veritabanını Oluşturun**
   - XAMPP/WAMP'ı başlatın
   - phpMyAdmin'e gidin (`http://localhost/phpmyadmin`)
   - `esma_portfolio` veritabanını oluşturun
   - `sql/setup.sql` dosyasını içe aktarın
   
   VEYA komut satırından:
   ```bash
   mysql -u root -p < sql/setup.sql
   ```

3. **Veritabanı Ayarlarını Yapın**
   - `includes/db.php` dosyasını açın
   - Gerekirse DB_HOST, DB_USER, DB_PASS, DB_NAME değerlerini güncelleyin

4. **Projeyi Çalıştırın**
   - Proje klasörünü `htdocs` (XAMPP) veya `www` (WAMP) içine koyun
   - Tarayıcıda `http://localhost/web_portfolio_template/` adresine gidin

5. **Admin Kullanıcısı Oluşturun**
   - Kayıt sayfasından (`pages/register.php`) yeni bir hesap oluşturun
   - Admin yetkisi vermek için phpMyAdmin'den `users` tablosunda `role` alanını `admin` yapın

## Proje Yapısı

```
web_portfolio_template/
├── index.php                    # Ana sayfa
├── README.md                    # Bu dosya
├── .gitignore                   # Git ignore kuralları
├── sql/
│   └── setup.sql               # Veritabanı şeması
├── includes/
│   ├── db.php                  # Veritabanı bağlantısı
│   ├── functions.php           # Yardımcı fonksiyonlar
│   ├── header.php              # Ortak HTML başlığı
│   ├── footer.php              # Ortak HTML altbilgisi
│   └── navbar.php              # Ortak navigasyon çubuğu
├── pages/
│   ├── about.php               # Hakkımda sayfası
│   ├── contact.php             # İletişim sayfası
│   ├── projects.php            # Projeler sayfası (arama, filtreleme, sıralama)
│   ├── form.php                # İstek/Şikayet/Mektup formu
│   ├── login.php               # Giriş sayfası
│   ├── register.php            # Kayıt sayfası
│   ├── logout.php              # Çıkış işlemi
│   └── admin/
│       └── messages.php        # Admin paneli (mesaj yönetimi)
├── assests/
│   ├── css/
│   │   └── style.css           # Ana stil dosyası
│   └── js/
│       ├── main.js             # Ana JavaScript
│       └── script.js           # Etkileşim ve animasyonlar
└── data/
    └── projects.json           # Proje verileri (JSON)
```

## Veritabanı Şeması

### `users` Tablosu
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | INT AUTO_INCREMENT | Birincil anahtar |
| username | VARCHAR(50) | Kullanıcı adı (benzersiz) |
| email | VARCHAR(100) | E-posta adresi (benzersiz) |
| password | VARCHAR(255) | Şifre (hash'lenmiş) |
| full_name | VARCHAR(100) | Ad Soyad |
| role | ENUM | Kullanıcı rolü (user/admin) |
| created_at | TIMESTAMP | Kayıt tarihi |

### `messages` Tablosu
| Alan | Tip | Açıklama |
|------|-----|----------|
| id | INT AUTO_INCREMENT | Birincil anahtar |
| name | VARCHAR(100) | Gönderenin adı |
| email | VARCHAR(100) | Gönderenin e-postası |
| phone | VARCHAR(20) | Telefon numarası |
| msg_type | ENUM | Mesaj türü (istek/sikayet/mektup/diger) |
| subject | VARCHAR(200) | Mesaj konusu |
| message | TEXT | Mesaj içeriği |
| is_read | TINYINT | Okunma durumu (0/1) |
| created_at | TIMESTAMP | Gönderim tarihi |

## Ekran Görüntüleri

- **Ana Sayfa** - Hero section ile karşılama ekranı
- **Hakkımda** - Kişisel bilgiler ve beceriler
- **Projeler** - Arama, filtreleme ve sıralama özellikli proje galerisi
- **İletişim** - Sosyal medya linkleri ve hızlı mesaj formu
- **Form** - Detaylı istek/şikayet/mektup formu (DB kaydı)
- **Giriş/Kayıt** - Kullanıcı kimlik doğrulama sistemi
- **Admin Paneli** - Mesaj yönetim ekranı (admin yetkisi gerektirir)

## Geliştirici

**Esma Altug**
- Bölüm: Bilgisayar Programcılığı
- Üniversite: Kırşehir Ahi Evran Üniversitesi
- GitHub: [@EsiAltug0](https://github.com/EsiAltug0)

## Lisans

Bu proje eğitim amaçlı geliştirilmiştir. Tüm hakları saklıdır.

---

*2026 Esma Portfolio - Web Programlama Final Projesi*
