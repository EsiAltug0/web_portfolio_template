<?php
// ============================================
// ANA SAYFA
// Portfolio ana sayfası - Hero section
// ============================================
$pageTitle = 'Portfolio 2026';
$basePath = '';
$navBasePath = '';

require_once __DIR__ . '/includes/header.php';
?>

<?php include __DIR__ . '/includes/navbar.php'; ?>

<!-- Pages Container -->
<main class="pages-container">
    <!-- PAGE: HOME -->
    <section id="page-home" class="page active">
        <div class="hero-section">
            <div class="hero-bg"></div>
            <div class="hero-overlay"></div>
            <div class="hero-grid"></div>
            
            <div class="hero-content">
                <div class="hero-left">
                    <div class="hero-tag animate-fade-in-up">
                        <span class="tag-text">PORTFOLIO 2026</span>
                        <div class="tag-line"></div>
                    </div>

                    <h1 class="hero-title glitch-text" data-text="PORTFOLIO">PORTFOLIO</h1>
                    <h2 class="hero-name">ESMA</h2>

                    <div class="hero-role">
                        <span class="role-dot"></span>
                        <span>Tasarım & Yazılım Geliştirici</span>
                    </div>

                    <nav class="hero-menu">
                        <a href="pages/about.php" class="hero-menu-item" style="text-decoration: none; color: inherit;">
                            <span class="menu-line"></span>
                            <span class="menu-text">HAKKIMDA</span>
                        </a>
                        <a href="pages/projects.php" class="hero-menu-item" style="text-decoration: none; color: inherit;">
                            <span class="menu-line"></span>
                            <span class="menu-text">PROJELER</span>
                        </a>
                        <a href="pages/contact.php" class="hero-menu-item" style="text-decoration: none; color: inherit;">
                            <span class="menu-line"></span>
                            <span class="menu-text">İLETİŞİM</span>
                        </a>
                    </nav>
                </div>

                <div class="hero-right">
                    <div class="rotating-rings">
                        <div class="ring ring-1"></div>
                        <div class="ring ring-2"></div>
                        <div class="center-circle"><span>E</span></div>
                        <div class="floating-dot dot-1"></div>
                        <div class="floating-dot dot-2"></div>
                        <div class="floating-dot dot-3"></div>
                        <div class="floating-dot dot-4"></div>
                        <div class="floating-dot dot-5"></div>
                        <div class="floating-dot dot-6"></div>
                    </div>
                </div>
            </div>

            <div class="scroll-indicator">
                <span>SCROLL</span>
                <div class="scroll-line"></div>
            </div>
        </div>
    </section>
</main>

<?php 
$footerBasePath = '';
include __DIR__ . '/includes/footer.php'; 
?>
